from tkinter import * #import all library

o = Tk()
o.geometry('600x400') #widthXheight
o.title('My First Application')

#create label
c_name = Label(text='Computer Name ')
c_name.pack() #show to frame

c_text = Entry()  #create textbox or textfield 
c_text.pack()  #pack will show to frame

#create ip of computer
c_ip= Label(text='Computer IP')
c_ip.pack() #show to frame


c_ip_txt = Entry()  #create textbox or textfield 
c_ip_txt.pack()  #pack will show to frame

#msg
msg = Label(text='')
msg.pack()

#create a function
def event():
    print('Hey, you have clicked on button')
    #read form entere data
    cname = c_text.get()
    cip = c_ip_txt.get()

    print('you have entered ',cname,cip)

    if cname =='dev-server':
        print('contact to development team to get any assistence')
        msg.configure(text='contact to development team to get any assistence')

    elif cname =='test-server':
        print('contact to support team to get any assistence')
        msg.configure(text='contact to support team to get any assistence')
        

    elif cname=='prod-server':
        print('contact to prod team to get any assistence')
        msg.configure(text='contact to prod team to get any assistence')
    else:
        print('call to cutomer care ')
        msg.configure(text='call to cutomer care ')
        
        
        
        
    
    
    
#create button
b = Button(text='Click Me ',fg="red", bg="blue",command=event) #assign event to button 
b.pack()


o.mainloop()


