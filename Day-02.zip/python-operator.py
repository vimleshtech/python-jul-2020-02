a = int(input('enter data '))
b = int(input('enter data '))

#addition 
c =a+b
print(c)

#sub
c =a-b
print(c)

#mul
c =a*b
print(c)

#raise 
c =a**b
print(c)


#div
c =a/b
print(c)

#divv //
c =a//b
print(c)

#%
c =a%b
print(c)




