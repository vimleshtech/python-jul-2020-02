#read data from user
name = input('enter data ')
salary = input('enter salary ')

#print data type
print(type(name)) # type is funtion which return data type 
print(type(salary))

#pritn data / output
print(name)
print(salary)

print('name is ',end='')
print(name)




