#python is indentaion base langauge 
# tab :  forward 
# shift+tab : backward
#wap to enter amt and add 18% tax if amout is greater than 1000
amt = int(input('enter amt '))
tax = 0

if amt>1000:
    tax= amt*.18 # 18% 

total = amt+tax 
print('total amt is ',total)



##
a= int(input('enter data  '))
b= int(input('enter data  '))

#if else 
if a>b:
    print('a is greater')
else:
    print('b is greater')


##wap to calculate the tax based on amout 
amt = int(input('enter data '))
t = 0
if amt>1000:
    t = amt*.18
elif amt>500:
    t = amt*.12
elif amt>200:
    t = amt*.10
else:
    t = amt*.05 

total = amt+t 
print('total ',total)

#nested if 
a = int(input('enter data '))
b = int(input('enter data '))
c = int(input('enter data '))

if a>b:
    if a>c:
        print('a is greater')
    else:
        print('c is greater')
else:
    if b>c:
        print('b is greater')
    else:
        print('c is greater')

#or using and
if a>b and a>c:
    print('a si gt')
elif b>a and b>c:
    print('b is gt')
else:
    print('c is gt ')
    







