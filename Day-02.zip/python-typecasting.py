n1 = input('enter data ')
n2 = input('enter data ')

#type casting 
n1 = int(n1)
n2 = int(n2) 

#get the sum 
n = n1+n2 #addition 

print(n)



#example 2
a = int(input('enter data '))
b = int(input('enter data '))

c = a*b 
print(c)


