import mysql.connector as con
from tkinter import *


o = Tk()

fname = Label(text='Enter first name :')
fname.pack()

ftext = Entry()
ftext.pack()

lname = Label(text='Enter last name :')
lname.pack()

ltext = Entry()
ltext.pack()

msg = Label(text='Data is not saved yet')
msg.pack()

##craete function and event
def save():
    fn = ftext.get()
    ln = ltext.get()
    print('you have entered ',fn,ln)

    #establish the sql connection
    c=con.connect(host='localhost',user='root',password='root',database='hrms')
    cur = c.cursor()

    #"+fn+"
    cur.execute("insert into employee(fname,lname) values('"+fn+"','"+ln+"')")
    c.commit()
    msg.configure(text='data is saved')
    
    
    #clear form
    
    ftext.delete(0,END) #from 0 to end (all chars)
    ltext.delete(0,END)


btn=Button(text="Save",command=save)
btn.pack()




o.mainloop()



