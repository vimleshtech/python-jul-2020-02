import mysql.connector as con
from tkinter import *


o = Tk()

fname = Label(text='Enter first name :').grid(row=0,column=1)


ftext = Entry().grid(row=0,column=2)


lname = Label(text='Enter last name :').grid(row=1,column=1)

ltext = Entry().grid(row=1,column=2)

'''
bg=
fg
justify=left,right,center
width=100
height

'''



o.mainloop()



