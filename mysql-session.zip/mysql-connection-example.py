import mysql.connector as con


c = con.connect(host='127.0.0.1',user='root',password='root',database='salesdb')
#create an object of cursor
cur = c.cursor()


##fetch data 
cur.execute('select * from users;') #run sql statement 

res = cur.fetchall() #fetch data 


#print(res)
for row in res:
    print(row)
    

####



