import mysql.connector as con


c = con.connect(host='127.0.0.1',user='root',password='root',database='salesdb')
#create an object of cursor
cur = c.cursor()

cur.execute("insert into users(uid,name,gender) values(190,'Nitisha','female')")

c.commit() #save data



