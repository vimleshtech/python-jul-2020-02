#no argument no return
def welcome():
    print('Hey, This is first code in python with function ')

#no argument with return
def get_nums():
    a = int(input('enter data :'))
    b = int(input('enter data :'))

    return a,b

#argument with no return
def add(a,b):
    c =a+b
    print(c)

#argument with return
def sub(a,b):
    c =a-b
    return c

#argument with default value
def add_nums(a,b=0,c=0,d=0):
    m = a+b+c+d
    print(m)

#argument with dynmaic number of inputs
def mul(*arg):
    print(arg)
    print(type(arg))
    f =1
    for x in arg:
        f*=x
    print(f)

#lambda function
tax = lambda amt: amt*.18

####################################
####################################
#invoke to function
welcome()
welcome()


x,y= get_nums()
print(x*y)

add(11,566)
add(6,89)
add(60,891)


o = sub(11,5) #now o will receive the output and o can also resused 
print(o)

add(o,100) 


add_nums(1)
add_nums(5,61)
add_nums(6,77,81)
add_nums(1,7,4,7)

    
mul(11,3,6,7,78,8,4)
mul(11,3,6,7,78,8,4,66,23,677)

t = tax(100)
print(t)
