#python does allocate memory automatically , 
# a =44 #int
# a ='11' #str 

#int 
a =111
print(type(a))

#float 
a =111.444
print(type(a))

#str
a ='ffffghh 111.444'
print(type(a))
#or
a ="ffffghh 111.444"
print(type(a))

#bool / bit
b =True 
print(type(b))

########## multi values
#list
a = [111,44,5,'fjkfhhjfvgf',True,556]
print(type(a))
print(a)
print(a[1]) #print 2nd value 

a[1] = 9000 #change value
print(a)


#tuple
t =(111,4,6,2,'Test')
print(type(t))
print(t)
print(t[0])
#t[0] = 890 #error 

#dict 
d ={1:'one','a':'alpha','d':'delta',10:[1111,44,56,6,'test']}
print(type(d))
print(d)

print(d.keys())
print(d.values())

print(d[10])

k = list(d.keys())
#print(k[2]) #3rd 
print(d[k[1]])


#set : unique value 
s ={'iphone','hp laptop','iphone'}
print(s)
print(type(s))

