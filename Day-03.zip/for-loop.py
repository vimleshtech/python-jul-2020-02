#
for x in range(1,11):
    print(x)

#print in reverse
for x in range(10,0,-1):
    print(x)

#print all odd numbers between 1 to 100
for i in range(1,100,2):
    print(i)

#wap to print table of given number
t = int(input('enter data  '))    
for x in range(1,11):
    print('{} * {} = {}'.format(t,x,(t*x)))

#wap to print sum of all even and odd numbers between two numbers
n1 = int(input('enter first number  '))
n2 = int(input('enter last number  '))

se =0
so =0
for x in range(n1,n2+1): 
    if x % 2==0:
        se+=x 
    else:
        so+=x 

print('sum of all even number ',se)
print('sum of all odd numbers ',so)






