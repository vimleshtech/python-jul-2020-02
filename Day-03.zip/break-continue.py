for x in range(1,10):
    print(x)

#break

for x in range(1,10):
    if x % 4 ==0:
        break #stop the loop 
    print(x)
