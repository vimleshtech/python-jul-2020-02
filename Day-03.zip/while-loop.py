# print series  in ascending order
i =1  #start from / init 
while i<=10: #condition 
    print(i)
    i+=1 #step 


print('----------')
#print in descending order
i =10
while i>0:
    print(i)
    i-=1 

#wap to print all the odd numbers between 1 to 100
i =1
while i<=100:
    print(i,end=',')
    i+=2  #step 

#wap to print table of given number
t = int(input('enter data '))
i =1
while i<=10:
    #print(t*i)
    print('{} * {} = {}'.format(t,i,(t*i)))   # {} placeholder
    i+=1


#wap to get sum of all odd and even numbers between two given numbers
a = int(input('enter first number '))   #first number 
b = int(input('enter last number '))   #2nd number 

#declare variable assign default value 
se =0 
so = 0


while a<=b:  #condition 

    if a % 2 == 0: #if number is even
        se+=a   #add the sum(number) on se   se =se+a 
    else:
        so+=a 

    a+=1 

print('sum of all odd numbers ',se )
print('sum of all even numbers ',so)




