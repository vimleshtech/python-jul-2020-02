#declare empty list
data =[]

while True:
    choice = input('press 1 to add(create) data 2 for update 3 for delete 4 for view and press 0 for exist ')
    if choice=='1':
        val = input('enter value :')
        data.append(val)
        print('New vaue added ')
    elif choice=='2':
        val = input('enter existing value which you want to update ')
        pos = data.index(val)
        if pos>-1:
            nval  = input('enter new value :')
            data[pos] = nval
            print('value is updated ')
        else:
            print('given is value is not found ')
            

    elif choice=='3':
        val = input('enter value which you want to delete ')
        if val in data:
            data.remove(val)
            print('given value is removed')
        else:
            print('ginven value is not found')
            
        

    elif choice=='4':
        print(data)

    elif choice =='0':
        break
    else:
        print('invalid input, plz try again!!!')

        
        
    

    
    
        
        
    
