
s1 = input('enter string (one sentence) value or data :')
s2 = input('enter substring(one word) value or data :')


if s2 in s1:
    print('s2 {} is present in s1 {}'.format(s2,s1))

else:
    print('data is not match')


    
#or
if s1.find(s2)>-1:
    print('s2 is find in s1')
else:
    print('not found')


#or
if s1.count(s2)>0:
    print('s2 is match')
else:
    print('s2 is not match')




