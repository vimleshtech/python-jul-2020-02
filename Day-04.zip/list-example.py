#create list: collection of data or values
a = [111,33,5,6,7433,3,6,7] #list/array
#     0  1  2  3 4 

#print all data
print(a)

#print first value
print(a[0])

#print last value
print(a[-1])

#print 3rd value
print(a[2])


#get len
print(len(a))

#get max value
print(max(a))

#get lowest value
print(min(a))

#get total
print(sum(a))

##arrange data in asc order
a.sort()
print(a)

print(a[::-1]) #::  read from right to left -1 (-1 decrementer)

a= a[::-1] #reverse the data and store on variable 
print(a)


#get count
print(a.count(6))


#extend
a= [1,67,33,67]
b =[77,88,9]
print(a)
print(b)
a.extend(b) # merge b to a
print(a)


#pop remove from last 
a.pop()
a.pop()
print(a)

#append value / add at last position
a.append(100)
print(a)
a.append(10)
print(a)


#find value then remove
a.remove(33)
print(a)


#add value at given position
a.insert(2,987) #here 2 is position and 987 is data or value 
print(a)









