#enter number
n = int(input('enter num :'))

s  = 0
for x in range(1,n+1):  # 1,11  1...2  .. 9 ..10
    s =s+x
    
print('sum ',s)
print('average ',s/n)

    
