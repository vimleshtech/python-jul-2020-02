s = input('enter strign data :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.swapcase())


print(len(s))
print(s.replace('a','xy'))

print(s.strip()) #remove space from left and right 
print(s.lstrip()) #remove sapce from left
print(s.rstrip()) #remove space from right 


word = s.split(' ') #default is space, create list 
print(word)

print(word[1]) #get 2nd word 


l =list(s)
print(l)


c= s.count('a')
print(c)

if s.endswith('de'):
    print('ending with de')
else:
    print('not ending with de')


if s.startswith('ja'):
    print('start from ja')
else:
    print('not start from ja')


#
print(ord('A')) # A = 65 B = 66 .. Z 91 , a = 97, b= 98
print(chr(97))






    




    
