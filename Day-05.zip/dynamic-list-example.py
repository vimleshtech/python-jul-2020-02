#dynamic list example

#empty list
data = []

for x in range(5): #run loop 5 times
    d = int(input('enter data  ')) #read data from user
    data.append(d)  #add value in list


#print list 
print(data)


#list methods
print(max(data))
print(min(data))
print(sum(data))
print(len(data))

data.sort()
print(data)



    
