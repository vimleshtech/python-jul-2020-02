'''
0 1 2 3
0 1 2 3
0 1 2 3
'''

for x in range(3):
    for y in range(4):
        print(y,end=' ') #end='' don't change the line

    #new line
    print()
        

'''
0
1
2
3
0
1
2
3
0
1
2
3
..
'''

#pattern in increment order
'''
0
01
012
0123
'''
for x in range(8):
    for y in range(x+1): #0+1 =1  1+1=2
        print(y,end=' ') #end='' don't change the line

    #new line
    print()


    

        

