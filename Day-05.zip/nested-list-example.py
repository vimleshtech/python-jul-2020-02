#list iterator example 
data = [11,33,5,6,77333]

for i in range(len(data)): # len(data) return count
    print(data[i]) # data[0] data[1] data[2]

print('------')
#or
for m in data: #here m is new variable 
    print(m)

#nested list example
d =[[1,2,3],[5,6,7],[11,90,44]]  # 3 rows and 3 cols
'''
00=1 01 =2 02 = 3
10=5 11 =6 12 = 7
20=11 21 = 90 22 = 44

00 01 02
10 11 12
20 21 22
'''
print(d) #print all data

print(d[0]) #print first row

print(d[1][2]) #pritn 2nd row and 3rd col 

#using loop print row by row
for i in range(len(d)):
    print(d[i])
    
#print every value
for i in range(len(d)):
    for j in range(len(d[i])):
        print(d[i][j],end='\t')
    print()
    
        
