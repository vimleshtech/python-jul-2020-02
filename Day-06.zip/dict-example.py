#dict example
data={2:'alpha','a':'alpha',11:8333,'d':'data',10:[11,33,5,56,'nitin','male']}

print(type(data)) #print data type
print(data) #print key and values


#print all keys
print(data.keys())

#print all values
print(data.values())

#print / search value by key
print(data[10])
print(data['a'])#print value of given key 

#get items: key and value both in list format
o = data.items()
print(o)

#print all keys and values
for k,v in data.items():
    print(k,v)

#print key of given value
for a,b in data.items():  #here a,b are variables
    if b=='data':
        print(a)
        


#data
d ={'eid':[11,22,33,4,56],
    'name':['nitin','jatin','divya','ayush','vidhi'],
    'gender':['male','male','female','nale','female']}

print(d)

#change value/overwrite
d['eid'] =100
print(d)


#add new key and value
d['salary'] = [11,2,45,67,2]
print(d)

for a,b in d.items(): #here a is contain keys and b will contain value 
    print(b)

    
    








        
            
    
 


