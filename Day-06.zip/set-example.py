#set example
s ={'iphone','dove','iphone','laptop','tv'}

print(type(s)) #set

##print set all values
print(s)

#read every element one by one
for el in s: #here is set , and el is new varibale| data will copy from s to el
    print(el)


####use case of set: we want to get unique values
data = [111,55,6,6,2,2,4,6,7,22,'test',5454,True,False,True,'test',5532,22]

print(type(data))
print(data)

#get unique value
o1 = set(data)  #remove duplicate and store on set
o2 = list(set(data)) #remove duplicate and store back in list type
print(o1)
print(o2)


#check value is present or not
s ={'iphone','dove','iphone','laptop','tv'}
print('dove' in s)
print('hp' in s)

if 'dove' in s:
    print('product is match')
else:
    print('product is not match')


#add new  value in existing set
s.add('Sony TV')
print(s)

#update: add multiple items/data in one go
s.update(["Mac Laptop",True,111,555.2])
print(s)

#get count
print(len(s)) #get count

#remove existing value
s.remove('Sony TV') #remove if exist, and throw error if not exist
print(s)

#discard: remove value but will not throw error if not match
s.discard(True)
print(s)


#pop : remove last value (pop wil remove random value - from first, last), there is no use pop with set
print(s)
s.pop()
print(s)



#remove all data but variable will be avaiable 
s.clear()
print(s)


#remove memory/ dealloacte memory , variable wll be removed 
del s
#print(s) #error


#merge set| union
a ={1,2,4,6}
b ={'a',55,'b'}

c = a.union(b)
print(c)





























    
